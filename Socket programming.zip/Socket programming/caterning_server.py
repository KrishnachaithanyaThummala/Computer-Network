import socket
import json
import numpy as np
import pandas as pd
import csv
from csv import writer
import threading
from _thread import *
ServerSocket = socket.socket()

host = '192.168.56.1'
port = 1235
threadCount = 0
try:
    ServerSocket.bind((host, port))
except socket.error as e:
    print(str(e))
print('Waitiing for a Connection..')
ServerSocket.listen(5)
def client(connection):
    while True:
        data = connection.recv(6000).decode('utf-8')
        stationary = pd.read_csv(r"C:\Users\Vijay Kumar Tummala\Desktop\sem5\Computer network\CB.EN.U4CSE19153_LABS\data sets\CATERING-DEPARTMENT.csv")
        print(stationary)
        inp = data
        if(inp == "I"):
            name = connection.recv(6000).decode("utf-8")
            iten_name = connection.recv(6000).decode("utf-8")
            quantity = connection.recv(6000).decode("utf-8")
            station = connection.recv(6000).decode("utf-8")
            train_name = connection.recv(6000).decode("utf-8")
            time = connection.recv(6000).decode("utf-8")
            timestamp = connection.recv(6000).decode("utf-8")
            status = connection.recv(6000).decode("utf-8")
            insert_row = [pd.Series([name,iten_name,quantity,station,train_name,time,timestamp,status],index = stationary.columns)]    
            
            stationary = stationary.append(insert_row, ignore_index = True) 
            print(stationary)
            stationary.to_csv(r"C:\Users\Vijay Kumar Tummala\Desktop\sem5\Computer network\CB.EN.U4CSE19153_LABS\data sets\CATERING-DEPARTMENT.csv")
            print("your order is booked")
            connection.send(bytes(r"C:/Users/Vijay Kumar Tummala/Desktop/sem5/Computer network/CB.EN.U4CSE19153_LABS/data sets/CATERING-DEPARTMENT.csv","utf-8"))
                     
        elif(inp == "M"):
            index_name = connection.recv(6000).decode("utf-8")
            status = connection.recv(6000).decode("utf-8")
            oderstatus = connection.recv(6000).decode("utf-8")
            #stationary.at[indexname],[status] =[oderstatus]
            #print('your ordered  is canceled')
            stationary.loc[index_name, 'status'] = [oderstatus] 
            stationary.to_csv(r"C:\Users\Vijay Kumar Tummala\Desktop\sem5\Computer network\CB.EN.U4CSE19153_LABS\data sets\CATERING-DEPARTMENT.csv", index=False)
            print(stationary)             
        elif(inp == "V"):
            connection.send(bytes(r"C:/Users/Vijay Kumar Tummala/Desktop/sem5/Computer network/CB.EN.U4CSE19153_LABS/data sets/CATERING-DEPARTMENT.csv","utf-8"))
        elif(inp == "W"):
            connection.send(bytes(r"C:/Users/Vijay Kumar Tummala/Desktop/sem5/Computer network/CB.EN.U4CSE19153_LABS/data sets/items_list.csv","utf-8"))    
        if not data:
            break
    connection.close()
while True:
    Client, address = ServerSocket.accept()
    print('Connected to: ' + address[0] + ':' + str(address[1]))
    threadCount += 1
    print('thread Number: ' + str(threadCount))
    thread=threading.Thread(target=client,args=(Client))
    thread.start()
    client(Client)
ServerSocket.close()