import socket
import os
from _thread import *
import datetime
import json
import pandas as pd
from numpy import cos
ClientSocket = socket.socket()
host = '192.168.56.1'
port = 1235
print('Waiting for connection')
try:
    ClientSocket.connect((host, port))
except socket.error as e:
    print(str(e))
while True:
    print("****************please press the following charecter of your choise***********************")
    print("1.For veiwing the menu card please press : W")
    print("2.For odering the food please press : I")
    print("3.For canceling the order  please press : M")
    print("4.For  Viewing oder the status please press : V")
    print("*****************************end**********************************************************")
    inp = str(input('ENTER THE CHARECTER :'))
    ClientSocket.send(str(inp).encode("utf-8"))
    canContinue = True
    if(inp == "I"):
        name = input("name : ")
        ClientSocket.send(name.encode("utf-8"))
        item_name = input("item_name : ")
        ClientSocket.send(item_name.encode("utf-8"))
        quantity = input("quantity : ")
        ClientSocket.send(quantity.encode("utf-8"))
        station = input("station : ")
        ClientSocket.send(station.encode("utf-8"))
        train_name = input("train_name : ")
        ClientSocket.send(train_name.encode("utf-8"))
        time = input("time : ")
        ClientSocket.send(time.encode("utf-8"))
        timestamp = input("am/pm :")
        ClientSocket.send(timestamp.encode("utf-8"))
        status = input("cancel/update : ")
        ClientSocket.send(status.encode("utf-8"))
        print(pd.read_csv(ClientSocket.recv(60000).decode("utf-8")))
    elif(inp == "M"):
        indexname = input("please enter your name :")
        ClientSocket.send(indexname.encode("utf-8"))
        status = input("ordered :")
        ClientSocket.send(status.encode("utf-8"))
        oderstatus = input("cancel/update :")
        ClientSocket.send(oderstatus.encode("utf-8"))
    elif(inp == "V"):
        d = ["V"]
        ClientSocket.send(str(d).encode("utf-8"))
        print(pd.read_csv(ClientSocket.recv(60000).decode("utf-8")))
    elif(inp == "W"):
        d = ["W"]
        ClientSocket.send(str(d).encode("utf-8"))
        print(pd.read_csv(ClientSocket.recv(60000).decode("utf-8")))    
    else:
        canContinue = False
        print("Wrong Input")
ClientSocket.close()